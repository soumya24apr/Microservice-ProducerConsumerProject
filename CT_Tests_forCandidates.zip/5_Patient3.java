import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class Main {


	// fill in implementations for these methods

	public static void removeDuplicatePatient(List<Patient> patients) {
		// remove duplicate patient from the dataset
	}

	public static void printPatient(List<Patient> patients) {
		//print Patients having sugar level more than 100 and visit more than 3
		System.out.println("\nPrint Patient sugar > 100, visit > 3:");

	}

	public static List<Patient> changeLocation(List<Patient> patients) {
		// Change the location of Patients from Delhi to "Chennai" if sugar level more than 100
		return null;
	}


	public static Map<Double, Patient> sugarLevelMap(List<Patient> patients) {
		// return a Map of PatientNo -> Patient sorted based on their sugar level in
		// descending order
		return null;
	}

	// don't modify anything under here

	public static void main(String[] args) {

		final Patient patient1 = new Patient(1000, new Double(72), "Mumbai", 3);

		final Patient patient2 = new Patient(2000, new Double(90), "Delhi", 2);

		final Patient patient3 = new Patient(1111, new Double(140), "Delhi", 1);

		final Patient patient4 = new Patient(2121, new Double(150), "Mumbai", 4);
		
		final Patient patient5 = new Patient(1000, new Double(72), "Mumbai", 2);

		final List<Patient> patients = new ArrayList<>(Arrays.asList(patient1, null, patient2, patient3, patient4,patient5));

    removeDuplicatePatient(patients);
    System.out.println("\nPatients after removing duplicates:" + patients);

    printPatient(patients);

		changeLocation(patients);

		System.out.println("\nPatients after changing location: " + patients);

		System.out.println("\nSugarLevelMap: " + sugarLevelMap(patients));


	}

	static class Patient implements Comparable<Patient> {

		long patientNo;
		String location;
		double sugarLevel;
		int visit;

		Patient(long patientNo, double sugarLevel,String location, int visit) {

			this.patientNo = patientNo;
			this.location = location;
			this.sugarLevel = sugarLevel;
			this.visit = visit;
		}

		public String toString() {

			return "Patient{patientNo=" + patientNo  + ",location=" + location +", sugarLevel=" + sugarLevel+ ",Visit=" + visit
					+ "}";
		}

		@Override
		public int compareTo(Patient o1) {
			return 0;
		}

	}


}
