import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class Main {

	// fill in implementations for these methods

	public static void removeDBs(List<DB> dbs) {
		// remove DBs which are not stable and price is greater than 21000

	}

	public static DB findDB(List<DB> dbs) {
		//return DB with lowest price
		return null;

	}

	public static List<DB> changeDBStatus(List<DB> dbs) {
		// Change location from UNSELECTED  to SELECTED if version is STABLE and price is minimum
		return null;
	}

	public static Map<Long, DB> dbMap(List<DB> dbs) {
		// return a Map of DBNo -> DB sorted based on their price  in
		// descending order
		return null;
	}

	// don't modify anything under here

	public static void main(String[] args) {
		


		final DB db1 = new DB(1000, "PostgreSQL", new Date(2017, 10, 31),"STABLE",new Double(10000), "UNSELECTED");

		final DB db2 = new DB(2000, "DB2", new Date(2018, 07, 03),"BETA",new Double(24500), "UNSELECTED");

		final DB db3 = new DB(1111, "Oracle", new Date(2016, 04, 01),"STABLE",new Double(25640), "UNSELECTED");

		final DB db4 = new DB(2121, "MySQL", new Date(2017, 05, 06),"BETA",new Double(20000),"UNSELECTED");

		final DB db5 = new DB(2121, "MSSQL", new Date(2018, 05, 06),"STABLE",new Double(15000),"UNSELECTED");

		final List<DB> databases = new ArrayList<>(Arrays.asList(db1, null, db2, db3, db4));

		System.out.println("\nDatabases before remove: " + databases);		
		removeDBs(databases);
		System.out.println("\nDatabases after remove: " + databases);
		
		System.out.println("\nfind DB: " + findDB(databases));

		changeDBStatus(databases);
	  System.out.println("\nDatabases after change status: " + databases);
		
		System.out.println("\ndbMap sorted on price: " + dbMap(databases));
	}

	static class DB implements Comparable<DB> {

		long dbId;
		String dBName;
		Date releaseDate;
		String version;
		Double price;
		String status;

		DB(long dbId,String dBName,Date releaseDate,String version,Double price, String status) {

			this.dbId = dbId;
			this.dBName= dBName;
			this.releaseDate = releaseDate;
			this.version = version;
			this.price = price;
			this.status = status;
		}

		public String toString() {

			return "DB{dbId=" + dbId + ", dbName=" + dBName + ",releaseDate=" + releaseDate + ",version=" + version+", price="+price +", status="+status
					+ "}";
		}

		@Override
		public int compareTo(DB o1) {
			return 0; // salary is also positive integer
		}

	}

}
