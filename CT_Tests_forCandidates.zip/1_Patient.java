import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Comparator;
import java.util.Collections;
import java.util.*;

public class Main {

	// Implement the following methods

	public static void hyperMumbaiPatients(List<Patient> patients) {
		// Print list of patients from Mumbai and blood pressure > 120
    System.out.println("Hyper active mumbai patients below: ");
  }

	public static List<Patient> replacePatient(List<Patient> patients) {
		// create a new patient with the followint values
    // patientNo=5000, sugarLevel=105, location=Pune, Visit=5, bloodPressure=130
    // replace patient with patientNo=2121 with new Patient.
    return patients;
	}

	public static void giveInsulin(List<Patient> patients) {
		// mark insulin true for patients with sugar > 100
	}


	public static Map<Long, Patient> visitMap(List<Patient> patients) {
		// return a Map of PatientNo -> Patient sorted based on their visit in descending order
    // hint - will you use Hashmap, TreeMap or LinkedHashMap
		return null;
	}

	// supporting code

	public static void main(String[] args) {

		final Patient patient1 = new Patient(1000, new Double(72), "Mumbai", 3, 120);

		final Patient patient2 = new Patient(2000, new Double(90), null, 2, 180);

		final Patient patient3 = new Patient(1111, new Double(140), "Delhi", 1, 200);

		final Patient patient4 = new Patient(2121, new Double(150), "Mumbai", 4, 150);

		final List<Patient> patients = new ArrayList<>(Arrays.asList(patient1, patient2, patient3, patient4));

		System.out.println("List of patients: \n" + patients + "\n");
		
    hyperMumbaiPatients(patients);

    System.out.println("\nReplace Patient: \n"+ replacePatient(patients));

		giveInsulin(patients);

		System.out.println("\npatients given insulin: \n" + patients + "\n");

		System.out.println("\nMap descending visit order: \n" + visitMap(patients));
	}

	static class Patient {

		long patientNo;
		double sugarLevel;
		String location;
		int visit;
		long bloodPressure;
    boolean insulin;

		Patient(long patientNo, double sugarLevel,String location, int visit, long bloodPressure) {

			this.patientNo = patientNo;
			this.sugarLevel = sugarLevel;
			this.location = location;
			this.visit = visit;
      this.bloodPressure = bloodPressure;
		}

		public String toString() {

			return "Patient{patientNo=" + patientNo  + ", sugarLevel=" + sugarLevel+ ", location=" + location +", Visit=" + visit + ", bloodPressure="+bloodPressure+ ", insulin="+insulin+"}";
		}

	}
  
}
