import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class Main {


	// fill in implementations for these methods

	public static void DiabeticPatient(List<Patient> patients) {
		// Print list of patients having sugarLevel range between 100 to 200
    System.out.println("\nDiabetic patients below:");

	}

	public static Patient findPatient(List<Patient> patients) {
		//return Patients ID 1111;
		return null;

	}

	public static List<Patient> changeLocation(List<Patient> patients) {
		// Change the location of Patients from Delhi to "Chennai"
		return null;
	}


	public static Map<Long, Patient> visitMap(List<Patient> patients) {
		// return a Map of PatientNo -> Patient sorted based on their visit in
		// descending order
		return null;
	}

	// don't modify anything under here

	public static void main(String[] args) {

		final Patient patient1 = new Patient(1000, new Double(72), "Mumbai", 3);

		final Patient patient2 = new Patient(2000, new Double(90), "Delhi", 2);

		final Patient patient3 = new Patient(1111, new Double(140), "Delhi", 1);

		final Patient patient4 = new Patient(2121, new Double(150), "Mumbai", 4);

		final List<Patient> patients = new ArrayList<>(Arrays.asList(patient1, null, patient2, patient3, patient4));

    DiabeticPatient(patients);

		System.out.println("\nFind Patient:" + findPatient(patients));

		changeLocation(patients);

		System.out.println("\nPatients after changing location: " + patients);

		System.out.println("\nVisitMap: " + visitMap(patients));
	}

	static class Patient implements Comparable<Patient> {

		long patientNo;
		String location;
		double sugarLevel;
		double bloodPressure;
		int visit;
		String skill;

		Patient(long patientNo, double sugarLevel,String location, int visit) {

			this.patientNo = patientNo;
			this.location = location;
			this.sugarLevel = sugarLevel;
			this.visit = visit;
		}

		public String toString() {

			return "Patient{patientNo=" + patientNo  + ",location=" + location +", sugarLevel=" + sugarLevel+ ",Visit=" + visit
					+ "}";
		}

		@Override
		public int compareTo(Patient o1) {
			return 0;
		}

	}


}
