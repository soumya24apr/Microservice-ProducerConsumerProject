import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
/**
 * 
 * Employee Management
 *
 */
public class Main {

	// fill in implementations for these methods

	public static boolean isOne(Employee employee) {
		// return true if this Employee's employeeNo starts with 1
		return false;

	}

	public static void cleanNames(List<Employee> employees) {
		// change location like "Bombay" -> "Mumbai", "Madras" -> "Chennai", anything
		// else leave alone

	}

	public static void removeDubai(List<Employee> employees) {
		// remove employees from location Dubai

	}

	public static Map<Long, Employee> richMap(List<Employee> employees) {
		// return a Map of EmployeeNo -> Employee only for people who's salary is >
		// 25000
		return null;
	}

	public static Map<Long, Employee> salaryMap(List<Employee> employees) {
		// return a Map of EmployeeNo -> Employee sorted based on their salary in
		// ascending order
		return null;
	}

	// don't modify anything under here

	public static void main(String[] args) {

		final Employee emp1 = new Employee(1000, new Double(35000), "Bombay", new Date(2000, 10, 31));

		final Employee emp2 = new Employee(2000, new Double(20000), "Dubai", new Date(2001, 07, 03));

		final Employee emp3 = new Employee(1111, new Double(25000), "Madras", new Date(1999, 04, 01));

		final Employee emp4 = new Employee(2121, new Double(50000), "Dubai", new Date(1978, 05, 06));

		final List<Employee> employees = new ArrayList<>(Arrays.asList(emp1, null, emp2, emp3, emp4));

    System.out.println("\nEmployees with numbers starting with one true:");

		System.out.println(emp1 + " isOne: " + isOne(emp1));

		System.out.println(emp2 + " isOne: " + isOne(emp2));

		System.out.println(emp3 + " isOne: " + isOne(emp3));

		System.out.println(emp4 + " isOne: " + isOne(emp4));

		cleanNames(employees);

		System.out.println("\nEmployees after clean: " + employees);

		removeDubai(employees);

		System.out.println("\nEmployees after removeDubai: " + employees);

		System.out.println("\nrichMap: " + richMap(employees));

		System.out.println("\nsalaryMap: " + salaryMap(employees));

	}

	static class Employee implements Comparable<Employee> {

		long employeeNo;
		String location;
		Date dob;
		Double salary;

		Employee(long employeeNo, Double salary, String location, Date dob) {

			this.employeeNo = employeeNo;
			this.salary = salary;
			this.location = location;
			this.dob = dob;
		}

		public String toString() {

			return "Employee{employeeNo=" + employeeNo + ",salary=" + salary + ",location=" + location + ",DOB=" + dob
					+ "}";
		}

		@Override
		public int compareTo(Employee o1) {
			Double salDiff = this.salary - o1.salary;
			int diff = salDiff.intValue();
			return diff; // salary is also positive integer
		}

	}

}
